#include <FastLED.h>

bool * getLetterArray(char, int);
int getLetterLength(char);
bool * get_sub_array(bool, int, int);
void clear_letters();
