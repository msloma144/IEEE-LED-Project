bool *A = new bool[5*5] {
        0, 0, 1, 0, 0,
        0, 1, 1, 1, 0,
        1, 0, 0, 0, 1,
        1, 1, 1, 1, 1,
        1, 0, 0, 0, 1
};
int A_length = 5;

bool *B  = new bool[5*3] {
        1, 1, 0,
        1, 0, 1,
        1, 1, 0,
        1, 0, 1,
        1, 1, 0
};
int B_length = 3;

bool *C = new bool[5*4] {
        0, 1, 1, 1,
        1, 1, 0, 0,
        1, 1, 0, 0,
        1, 1, 0, 0,
        0, 1, 1, 1
};
int C_length = 4;

bool *D = new bool[5*3] {
        1, 1, 0,
        1, 0, 1,
        1, 0, 1,
        1, 0, 1,
        1, 1, 0
};
int D_length = 3;

bool *E = new bool[5*3] {
        1, 1, 1,
        1, 0, 0,
        1, 1, 1,
        1, 0, 0,
        1, 1, 1
};
int E_length = 3;

bool *F = new bool[5*3] {
        1, 1, 1,
        1, 0, 0,
        1, 1, 1,
        1, 0, 0,
        1, 0, 0
};
int F_length = 3;

bool *G = new bool[5*5] {
       0, 1, 1, 1, 0,
       1, 1, 0, 0, 0,
       1, 1, 0, 1, 1,
       1, 1, 0, 0, 1,
       0, 1, 1, 1, 0
};
int G_length = 5;

bool *H = new bool[5*4] {
        1, 0, 0, 1,
        1, 0, 0, 1,
        1, 1, 1, 1,
        1, 0, 0, 1,
        1, 0, 0, 1
};
int H_length = 4;

bool *I = new bool[5*3] {
        1, 1, 1,
        0, 1, 0,
        0, 1, 0,
        0, 1, 0,
        1, 1, 1
};
int I_length = 3;

bool *J = new bool[5*4] {
        1, 1, 1, 1,
        0, 0, 1, 0,
        0, 0, 1, 0,
        1, 0, 1, 0,
        1, 1, 1, 0
};
int J_length = 4;

bool *K = new bool[5*3] {
        1, 0, 1,
        1, 1, 0,
        1, 1, 0,
        1, 1, 0,
        1, 0, 1
};
int K_length = 3;

bool *L = new bool[5*3] {
        1, 0, 0,
        1, 0, 0,
        1, 0, 0,
        1, 0, 0,
        1, 1, 1
};
int L_length = 3;

bool *M = new bool[5*5] {
        1, 0, 0, 0, 1,
        1, 1, 0, 1, 1,
        1, 0, 1, 0, 1,
        1, 0, 0, 0, 1,
        1, 0, 0, 0, 1
};
int M_length = 5;

bool *N = new bool[5*5] {
        1, 0, 0, 0, 1,
        1, 1, 0, 0, 1,
        1, 0, 1, 0, 1,
        1, 0, 0, 1, 1,
        1, 0, 0, 0, 1
};
int N_length = 5;

bool *O = new bool[5*4] {
        0, 1, 1, 0,
        1, 0, 0, 1,
        1, 0, 0, 1,
        1, 0, 0, 1,
        0, 1, 1, 0
};
int O_length = 4;

bool *P = new bool[5*3] {
        1, 1, 1,
        1, 0, 1,
        1, 1, 1,
        1, 0, 0,
        1, 0, 0
};
int P_length = 3;

bool *Q = new bool[5*5] {
        0, 1, 1, 0, 0,
        1, 0, 0, 1, 0,
        1, 0, 0, 1, 0,
        1, 0, 0, 1, 0,
        0, 1, 1, 1, 1
};
int Q_length = 5;

bool *R = new bool[5*4] {
        1, 1, 1, 0,
        1, 0, 1, 0,
        1, 1, 1, 0,
        1, 0, 1, 0,
        1, 0, 0, 1
};
int R_length = 4;

bool *S = new bool[5*5] {
        1, 1, 1, 1, 0,
        0, 0, 1, 1, 1,
        0, 1, 1, 0, 0,
        1, 1, 0, 0, 0,
        0, 1, 1, 1, 1
};
int S_length = 5;

bool *T = new bool[5*5] {
        1, 1, 1, 1, 1,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0,
        0, 0, 1, 0, 0
};
int T_length = 5;

bool *U = new bool[5*4] {
        1, 0, 0, 1,
        1, 0, 0, 1,
        1, 0, 0, 1,
        1, 0, 0, 1,
        1, 1, 1, 1
};
int U_length = 4;

bool *V = new bool[5*5] {
        1, 0, 0, 0, 1,
        1, 1, 0, 1, 1,
        0, 1, 0, 1, 0,
        0, 1, 1, 1, 0,
        0, 0, 1, 0, 0
};
int V_length = 5;

bool *W = new bool[5*5] {
        1, 0, 0, 0, 1,
        1, 0, 0, 0, 1,
        1, 0, 1, 0, 1,
        0, 1, 1, 1, 0,
        0, 1, 0, 1, 0
};
int W_length = 5;

bool *X = new bool[5*5] {
        1, 0, 0, 0, 1,
        0, 1, 0, 1, 0,
        0, 0, 1, 0, 0,
        0, 1, 0, 1, 0,
        1, 0, 0, 0, 1
};
int X_length = 5;

bool *Y = new bool[5*3] {
        1, 0, 1,
        0, 1, 0,
        0, 1, 0,
        0, 1, 0,
        0, 1, 0
};
int Y_length = 3;

bool *Z = new bool[5*5] {
        1, 1, 1, 1, 1,
        0, 0, 0, 1, 0,
        1, 1, 1, 1, 1,
        0, 1, 0, 0, 0,
        1, 1, 1, 1, 1
};
int Z_length = 5;

bool *space_large = new bool[5*2] {
        0, 0,
        0, 0,
        0, 0,
        0, 0,
        0, 0
};
int space_large_length = 2;

bool *space_small = new bool[5*1] {
        0,
        0,
        0,
        0,
        0
};
int space_small_length = 1;

bool *one = new bool[5*3] {
        0, 1, 0,
        1, 1, 0,
        0, 1, 0,
        0, 1, 0,
        1, 1, 1
};
int one_length = 3;

bool *two = new bool[5*4] {
        1, 1, 1, 0,
        1, 0, 0, 1,
        0, 0, 1, 0,
        0, 1, 0, 0,
        1, 1, 1, 1
};
int two_length = 4;

bool *three = new bool[5*3] {
        0, 1, 1,
        1, 0, 0,
        1, 1, 1,
        1, 0, 0,
        0, 1, 1
};
int three_length = 3;

bool *four = new bool[5*3] {
        1, 0, 1,
        1, 0, 1,
        1, 1, 1,
        0, 0, 1,
        0, 0, 1
};
int four_length = 3;

bool *five = new bool[5*3] {
        1, 1, 1,
        1, 0, 0,
        1, 1, 1,
        0, 0, 1,
        1, 1, 1
};
int five_length = 3;

bool *six = new bool[5*3] {
        1, 1, 1,
        1, 0, 0,
        1, 1, 1,
        1, 0, 1,
        1, 1, 1
};
int six_length = 3;

bool *seven = new bool[5*4] {
        1, 1, 1, 1,
        0, 0, 0, 1,
        0, 0, 1, 0,
        0, 1, 0, 0,
        1, 0, 0, 0
};
int seven_length = 4;

bool *eight = new bool[5*3] {
        1, 1, 1,
        1, 0, 1,
        0, 1, 0,
        1, 0, 1,
        1, 1, 1,
};
int eight_length = 3;

bool *nine = new bool[5*3] {
        1, 1, 1,
        1, 0, 1,
        1, 1, 1,
        0, 0, 1,
        0, 0, 1,
};
int nine_length = 3;

bool *zero = new bool[5*4] {
        0, 1, 1, 0,
        1, 0, 0, 1,
        1, 0, 0, 1,
        1, 0, 0, 1,
        0, 1, 1, 0
};
int zero_length = 4;

bool *at = new bool[5*5] {
        0, 1, 1, 1, 1,
        1, 0, 1, 1, 1,
        1, 1, 0, 1, 1,
        1, 0, 1, 1, 1,
        0, 1, 1, 0, 0
};
int at_length = 5;

bool *colon = new bool[5*1] {
        0,
        1,
        0,
        1,
        0
};
int colon_length = 1;
